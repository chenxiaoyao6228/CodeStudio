# ⚡vite-react-eslint-prettier starter⚡

An easy solution for vite, reactjs, eslint & prettier setup for react projects.

## Requirements

-   Visual Studio Code Editor &
-   It's two extension - `ESlint` , `Prettier`

## Features

-   Faster development experience
-   Instant Reload in Browser Preview
-   Amazing linting and formatting to indentify error easily

## Usage

-   **Clone/Download this repo in your Project Directory**
-   then use ```npm install``` or ```yarn install``` to install project dependecies
-   then use ```npm dev``` or ```yarn dev``` to run the project server
-   then use ```npm build``` or ```yarn build``` to get production build

## Support

If it helps me, leave a star, Thank you💖💖

## License

[MIT](https://choosealicense.com/licenses/mit/)
