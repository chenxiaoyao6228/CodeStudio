import React from 'react';

const a = 1
const flat = a == 1;

function App() {
    return (
        <div>
            <center>
                <h1>Vite + React Boilerplate</h1>
            </center>
        </div>
    );
}

export default App;
