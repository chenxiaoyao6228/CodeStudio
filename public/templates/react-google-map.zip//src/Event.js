import React, { Component } from "react";
 
class Event extends Component {
  render() {
    return (
      <div>
        <h2>EDM NIGHT IN TORONTO</h2>
        <p>Event Details: </p>
        <ol>
          <li>Location: Yonge-Dundas Square, Toronto</li>
          <li>Date: 27th January 2020</li>
          <li>Hours:6 PM - 10 PM</li>
          <li>Artists: Deadmau5, Above and Beyond, Tïesto </li>
          <li>Accomodates: Approx 20K people</li>
          <li>Bar: Budweiser, Corona, Stella Artois and Heineken available</li>
          <li>Access types: GA, Staff, VIP, VVIP </li>
          <li>Number of entraces:2</li>
          <li>Number of Exits: 2</li>
          <li>Number of lanes:10</li>
          <li>Zones: Backstage, Stage, VVIP zone, VIP zone and GA zone</li>
        
        </ol>
      </div>
    );
  }
}
 
export default Event;