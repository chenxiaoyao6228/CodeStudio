import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>
        <h2>Welcome to EDM Night 2020</h2>
        <p></p>
        <p></p>
      </div>
    );
  }
}
 
export default Home;