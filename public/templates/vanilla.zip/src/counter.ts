import axios, { CancelToken } from 'axios';
import { sum } from 'lodash';

export function setupCounter(element: HTMLButtonElement) {
  let counter = 0;
  const setCounter = (count: number) => {
    counter = count;
    element.innerHTML = `count is ${counter}, sum is ${sum([1, 2, 3])}`;
  };
  element.addEventListener('click', () => setCounter(counter + 1));
  setCounter(0);
}
