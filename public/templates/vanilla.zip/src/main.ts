import './style.css';
import { setupCounter } from './counter';

document.addEventListener('DOMContentLoaded', () => {
  setupCounter(document.querySelector<HTMLButtonElement>('#counter')!);
});
